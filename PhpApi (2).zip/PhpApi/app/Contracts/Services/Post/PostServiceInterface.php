<?php

namespace App\Contracts\Services\Post;

interface PostServiceInterface
{
    public function PostCreate($request);
}