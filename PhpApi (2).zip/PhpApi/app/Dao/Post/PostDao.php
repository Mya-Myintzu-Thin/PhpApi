<?php

namespace App\Dao\Post;

use App\Contracts\Dao\Post\PostDaoInterface;
use App\Models\Post;

class PostDao implements PostDaoInterface
{ 
/**
   * create post function
   *
   * @return $post object
   */

  public function PostCreate($request)
  {
    $post = new Post([
      'title' => $request->get('title'),
      'comment' => $request->get('comment'),
    //   'created_user_id' => Auth::user()->id,
    //   'updated_user_id' => Auth::user()->id
    ]);
    $post->save();

    return $post;
  }


}