<?php

namespace App\Contracts\Services\User;

interface UserServiceInterface
{
  public function getUserList();
}
